﻿using System;

using System.ComponentModel.DataAnnotations;

namespace Oefening1.Models
{
    public class Product
    {
        public int Artikelnummer { get; set; }
        [Required(ErrorMessage = "Vul een naam in")]
        public string Naam { get; set; }
        [Required(ErrorMessage = "Vul een prijs in")]
        [Range(0, 100000.00, ErrorMessage = "Voer een prijs tussen 0 en 100000.00")]
        public double? Prijs { get; set; }
        public string Afbeelding { get; set; }
    }
}
