﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Oefening1.Models;

using Microsoft.Data.Sqlite;

using System.ComponentModel.DataAnnotations;
namespace Oefening1.Pages
{
    public class BestelModel : PageModel
    {
        SqliteConnection connection;

        [BindProperty (SupportsGet = true)]
        public int artikelnummer { get; set; }
        public Product shirt;

        [BindProperty, Required(ErrorMessage = "Voer een naam in"), Display(Name ="Jouw Naam:")]
        public string naam { get; set; }

        [BindProperty, Required(ErrorMessage = "Voer een adres in"), Display(Name = "Jouw Adres:")]
        public string adres { get; set; }

        [BindProperty, Required(ErrorMessage = "Voer een woonplaats in"), Display(Name = "Jouw Woonplaats:")]
        public string woonplaats { get; set; }

        public BestelModel()
        {
            SqliteConnectionStringBuilder connectionStringBuilder = new SqliteConnectionStringBuilder();
            connectionStringBuilder.DataSource = "fietskleding.db";
            connection = new SqliteConnection(connectionStringBuilder.ToString());
        }

        public IActionResult OnGet()
        {
            //string artikelnummer = Request.Query["artikelnummer"];

            if (artikelnummer != 0)
            {
                connection.Open();
                SqliteCommand command = connection.CreateCommand();
                command.CommandText = $"SELECT * FROM producten where id = {artikelnummer}";
                SqliteDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    shirt = new Product();

                    shirt.Artikelnummer = reader.GetInt32(0);    //id
                    shirt.Naam = reader.GetString(1);   //naam shirts
                    shirt.Prijs = reader.GetDouble(2); //prijs
                    shirt.Afbeelding = reader.GetString(3); //afbeelding
                }
                connection.Close();
                return Page();
            }
            else
            {
                return RedirectToPage("Error");
            }
        }


        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                connection.Open();
                SqliteCommand command = connection.CreateCommand();
                command.CommandText = $"INSERT INTO bestellingen (naam, adres, woonplaats, bestelling) VALUES ('{naam}', '{adres}', '{woonplaats}', {artikelnummer})";

                int result = command.ExecuteNonQuery();
                connection.Close();
                return RedirectToPage("Index");
            }
            return OnGet();
        }

        //Hieronder moet een OnPost methode toegevoegd worden, waarin het formulier uitgelezen wordt
        //en de bestelling naar de database wordt weggeschreven. Daarna wordt teruggesprongen naar
        //de indexpagina. Er hoeft geen melding te komen dat de bestelling gelukt is.
    }
}