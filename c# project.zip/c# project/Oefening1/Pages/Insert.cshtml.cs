using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Microsoft.Data.Sqlite;
using Oefening1.Models;

namespace Oefening1.Pages
{
    public class InsertModel : PageModel
    {
        SqliteConnection connection;

        [BindProperty]
        public Product shirt { get; set; }

        [BindProperty]
        public IFormFile Afbeelding { get; set; }

        private IWebHostEnvironment _environment;

        public InsertModel(IWebHostEnvironment environment)
        {
            _environment = environment;
            SqliteConnectionStringBuilder connectionStringBuilder = new SqliteConnectionStringBuilder();
            connectionStringBuilder.DataSource = "fietskleding.db";
            connection = new SqliteConnection(connectionStringBuilder.ToString());
        }

        public IActionResult OnPost()
        {
            if (Afbeelding != null)
            {
                if (Afbeelding.ContentType == "image/gif" ||
                    Afbeelding.ContentType == "image/jpeg" ||
                    Afbeelding.ContentType == "image/png")
                {

                    var file = Path.Combine(_environment.ContentRootPath, "wwwroot/Images", Afbeelding.FileName);
                    using (var fileStream = new FileStream(file, FileMode.Create))
                    {
                        Afbeelding.CopyTo(fileStream);
                        this.shirt.Afbeelding = Afbeelding.FileName;
                        
                    }
                }
                else
                {
                    ModelState.TryAddModelError("Afbeelding", "Dit is geen afbeelding");
                }
            }
            else
            {
                ModelState.AddModelError("Afbeelding", "Kies een afbeelding");
            }
            if (ModelState.IsValid)
            {
                connection.Open();
                SqliteCommand command = connection.CreateCommand();
                command.CommandText = $"INSERT INTO producten (naam, prijs, afbeelding) VALUES ('{shirt.Naam}', '{shirt.Prijs}', '{shirt.Afbeelding}')";

                int result = command.ExecuteNonQuery();
                connection.Close();
                return RedirectToPage("Beheer");
            }
            return Page();
        }
    }
}
