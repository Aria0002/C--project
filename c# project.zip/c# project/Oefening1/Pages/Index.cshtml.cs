﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Data.Sqlite;
using Oefening1.Models;


namespace Oefening1.Pages
{
    public class IndexModel : PageModel
    {
        SqliteConnection connection;
        public List<Product> shirts = new List<Product>();

        public IndexModel()
        {
            SqliteConnectionStringBuilder connectionStringBuilder = new SqliteConnectionStringBuilder();
            connectionStringBuilder.DataSource = "fietskleding.db";
            connection = new SqliteConnection(connectionStringBuilder.ToString());
        }

        public void OnGet()
        {

            connection.Open();
            SqliteCommand command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM producten";
            SqliteDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Product shirt = new Product();

                shirt.Artikelnummer = reader.GetInt32(0);  
                shirt.Naam = reader.GetString(1); 
                shirt.Prijs = reader.GetDouble(2); 
                shirt.Afbeelding = reader.GetString(3);

                shirts.Add(shirt);

            }
            connection.Close();
        }

    }
}