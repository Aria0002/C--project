using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Microsoft.Data.Sqlite;
using Oefening1.Models;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using System.IO;

namespace Oefening1.Pages
{
    public class UpdateModel : PageModel
    {
        SqliteConnection connection;

        [BindProperty]
        public Product shirt { get; set; }

        [BindProperty(SupportsGet =true)]
        public int updateArtikel { get; set; }

        [BindProperty]
        public IFormFile Afbeelding { get; set; }

        private IWebHostEnvironment _environment;

        public UpdateModel(IWebHostEnvironment environment)
        {
            _environment = environment;
            SqliteConnectionStringBuilder connectionStringBuilder = new SqliteConnectionStringBuilder();
            connectionStringBuilder.DataSource = "fietskleding.db";
            connection = new SqliteConnection(connectionStringBuilder.ToString());
        }

        public IActionResult OnGet()
        {

            if (HttpContext.Session.GetString("gebruiker") == null ||
                 HttpContext.Session.GetString("gebruiker") != "admin")
            {
                return RedirectToPage("Inlog");
            }

            if (updateArtikel != 0)
            {
                connection.Open();
                SqliteCommand command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM producten where ID =@updateArtikel;";
                command.Parameters.AddWithValue("updateArtikel", updateArtikel);
                SqliteDataReader reader1 = command.ExecuteReader();

                while (reader1.Read())
                {
                    shirt = new Product();

                    shirt.Artikelnummer = reader1.GetInt32(0); 
                    shirt.Naam = reader1.GetString(1);         
                    shirt.Prijs = reader1.GetDouble(2);         
                    shirt.Afbeelding = reader1.GetString(3);   
                }
                connection.Close();
                return Page();
            }
            return RedirectToPage("Beheer");
        }

        public IActionResult OnPost() 
        {
            if (HttpContext.Session.GetString("gebruiker") == null ||
                HttpContext.Session.GetString("gebruiker") != "admin")
            {
                return RedirectToPage("Inlog");
            }

            if (Afbeelding != null)
            {
                if (Afbeelding.ContentType == "image/gif" ||
                    Afbeelding.ContentType == "image/jpeg" ||
                    Afbeelding.ContentType == "image/png" ||
                    Afbeelding.ContentType == "image/jpg")
                {

                    var file = Path.Combine(_environment.ContentRootPath, "wwwroot/Images", Afbeelding.FileName);
                    using (var fileStream = new FileStream(file, FileMode.Create))
                    {
                        Afbeelding.CopyTo(fileStream);
                        shirt.Afbeelding = Afbeelding.FileName;
                    }
                }
                else
                {
                    ModelState.AddModelError("Afbeelding", "Bestand is geen afbeelding");
                }

            }
            else
            {
                ModelState.AddModelError("Afbeelding", "Kies een afbeelding");
            }
            if (ModelState.IsValid)
            {
                connection.Open();
                SqliteCommand command = connection.CreateCommand();
                if (Afbeelding != null)
                {
                    command.CommandText = $"UPDATE producten SET naam = '{shirt.Naam}', prijs = {shirt.Prijs} , afbeelding = '{shirt.Afbeelding}' WHERE ID = {shirt.Artikelnummer} ";

                }
                else
                {
                    command.CommandText = $"UPDATE producten SET naam = '{shirt.Naam}', prijs = {shirt.Prijs} WHERE ID = {shirt.Artikelnummer} ";

                }

                int result = command.ExecuteNonQuery();
                connection.Close();

                return RedirectToPage("Beheer");
            }
            return Page();

        }
    }
}

