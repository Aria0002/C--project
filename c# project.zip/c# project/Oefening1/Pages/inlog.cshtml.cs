using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Oefening1.Pages
{
    public class InlogModel : PageModel
    {
        [BindProperty, Required(ErrorMessage = "Voer een naam in")]
        public string gebruikersnaam { get; set; }
        [BindProperty, Required(ErrorMessage = "Voer een wachtwoord in")]
        public string wachtwoord { get; set; }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                if (gebruikersnaam == "admin" && wachtwoord == "#1Geheim")
                {
                    HttpContext.Session.SetString("gebruiker", "admin");
                    return RedirectToPage("Beheer");
                }
                else
                {
                    ModelState.AddModelError("wachtwoord", "Onjuiste gebruikersnaam of wachtwoord");
                    return Page();
                }
            }
            return Page();
        }
    }
}
